package org.example;

public class ServiceTimeGenerator {

    // Given service (checkout) time data
    private static final int[] SERVICE_TIMES = {2, 3, 4, 5, 6};
    private static final double[] SERVICE_PROBS = {0.1, 0.25, 0.3, 0.2, 0.15};

    // 🧮 Print the service time probability table
    public static void printServiceTable() {
        double cumulative = 0.0;
        System.out.printf("%-15s %-15s %-25s%n",
                "Service Time", "Probability", "Cumulative Probability");
        System.out.println("---------------------------------------------------------");

        for (int i = 0; i < SERVICE_TIMES.length; i++) {
            cumulative += SERVICE_PROBS[i];
            System.out.printf("%-15d %-15.2f %-25.2f%n",
                    SERVICE_TIMES[i], SERVICE_PROBS[i], cumulative);
        }
        System.out.println();
    }

    // 🔢 Given a random number (0–1), return the corresponding service time
    public static int CalculateServiceTime(double rand) {
        double cumulative = 0.0;
        for (int i = 0; i < SERVICE_TIMES.length; i++) {
            cumulative += SERVICE_PROBS[i];
            if (rand <= cumulative) {
                return SERVICE_TIMES[i];
            }
        }
        return SERVICE_TIMES[SERVICE_TIMES.length - 1]; // fallback
    }
}
