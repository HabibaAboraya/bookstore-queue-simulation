package org.example;

public class InterArrivalGenerator {

    // Given interarrival data
    private static final int[] INTERARRIVAL_TIMES = {0, 1, 2, 3, 4, 5};
    private static final double[] INTERARRIVAL_PROBS = {0.1, 0.2, 0.3, 0.2, 0.1, 0.1};

    // Print the interarrival probability table
    public static void printInterarrivalTable() {
        double cumulative = 0.0;
        System.out.printf("%-15s %-15s %-25s%n",
                "Time Between", "Probability", "Cumulative Probability");
        System.out.println("---------------------------------------------------------");

        for (int i = 0; i < INTERARRIVAL_TIMES.length; i++) {
            cumulative += INTERARRIVAL_PROBS[i];
            System.out.printf("%-15d %-15.2f %-25.2f%n",
                    INTERARRIVAL_TIMES[i], INTERARRIVAL_PROBS[i], cumulative);
        }
        System.out.println();
    }

    // Given a random number (0–1), return the corresponding interarrival time
    public static int CalculateInterarrival(double rand) {
        double cumulative = 0.0;
        for (int i = 0; i < INTERARRIVAL_TIMES.length; i++) {
            cumulative += INTERARRIVAL_PROBS[i];
            if (rand <= cumulative) {
                return INTERARRIVAL_TIMES[i];
            }
        }
        return INTERARRIVAL_TIMES[INTERARRIVAL_TIMES.length - 1]; // fallback
    }
}
