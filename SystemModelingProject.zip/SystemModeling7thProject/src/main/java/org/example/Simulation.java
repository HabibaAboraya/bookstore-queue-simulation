package org.example;

import java.util.*;

public class Simulation {

    private static final int NUM_CUSTOMERS = 50;

    public static void runSimulation() {

        //Print cumulative tables
        System.out.println("INTER ARRIVAL TIME CUMULATIVE TABLE\n");
        InterArrivalGenerator.printInterarrivalTable();

        System.out.println("SERVICE TIME CUMULATIVE TABLE\n");
        ServiceTimeGenerator.printServiceTable();

        //Generate random numbers and map to times
        Random random = new Random();
        double[] randInterarrivals = new double[NUM_CUSTOMERS];
        double[] randServices = new double[NUM_CUSTOMERS];
        int[] interarrivalTimes = new int[NUM_CUSTOMERS];
        int[] serviceTimes = new int[NUM_CUSTOMERS];

        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            randInterarrivals[i] = random.nextDouble();
            randServices[i] = random.nextDouble();
            interarrivalTimes[i] = (i == 0) ? 0 :
                    InterArrivalGenerator.CalculateInterarrival(randInterarrivals[i]);
            serviceTimes[i] = ServiceTimeGenerator.CalculateServiceTime(randServices[i]);
        }

        //Print matching tables
        System.out.println("\nMATCHING TABLE - INTERARRIVAL TIME");
        System.out.printf("%-10s %-20s %-20s%n", "Cust#", "Random No.", "Interarrival Time");
        System.out.println("-----------------------------------------------------------");
        for (int i = 0; i < NUM_CUSTOMERS; i++)
            System.out.printf("%-10d %-20.2f %-20d%n", (i + 1), randInterarrivals[i], interarrivalTimes[i]);

        System.out.println("\nMATCHING TABLE - SERVICE TIME");
        System.out.printf("%-10s %-20s %-20s%n", "Cust#", "Random No.", "Service Time");
        System.out.println("-----------------------------------------------------------");
        for (int i = 0; i < NUM_CUSTOMERS; i++)
            System.out.printf("%-10d %-20.2f %-20d%n", (i + 1), randServices[i], serviceTimes[i]);

        //Initialize simulation arrays
        int[] arrivalTimes = new int[NUM_CUSTOMERS];
        int[] startTimes = new int[NUM_CUSTOMERS];
        int[] endTimes = new int[NUM_CUSTOMERS];
        int[] waitingTimes = new int[NUM_CUSTOMERS];
        int[] timeInSystem = new int[NUM_CUSTOMERS];
        int[] counterUsed = new int[NUM_CUSTOMERS];
        int[] queueLengths = new int[NUM_CUSTOMERS];
        int[] counter1IdleCol = new int[NUM_CUSTOMERS];
        int[] counter2IdleCol = new int[NUM_CUSTOMERS];

        int counter1AvailableAt = 0;
        int counter2AvailableAt = 0;

        //Main simulation logic
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            arrivalTimes[i] = (i == 0) ? 0 : arrivalTimes[i - 1] + interarrivalTimes[i];
            int startTime;
            int chosenCounter;
            int queueNo = 0;

            // Calculate idle time before this customer's service
            counter1IdleCol[i] = (arrivalTimes[i] > counter1AvailableAt)
                    ? arrivalTimes[i] - counter1AvailableAt : 0;
            counter2IdleCol[i] = (arrivalTimes[i] > counter2AvailableAt)
                    ? arrivalTimes[i] - counter2AvailableAt : 0;

            // Choose which counter will serve
            if (arrivalTimes[i] >= counter1AvailableAt) {
                chosenCounter = 1;
                startTime = arrivalTimes[i];
                counter1AvailableAt = startTime + serviceTimes[i];
            } else if (arrivalTimes[i] >= counter2AvailableAt) {
                chosenCounter = 2;
                startTime = arrivalTimes[i];
                counter2AvailableAt = startTime + serviceTimes[i];
            } else {
                if (counter1AvailableAt <= counter2AvailableAt) {
                    chosenCounter = 1;
                    queueNo = 1;
                    startTime = counter1AvailableAt;
                    counter1AvailableAt += serviceTimes[i];
                } else {
                    chosenCounter = 2;
                    queueNo = 1;
                    startTime = counter2AvailableAt;
                    counter2AvailableAt += serviceTimes[i];
                }
            }

            counterUsed[i] = chosenCounter;
            startTimes[i] = startTime;
            endTimes[i] = startTime + serviceTimes[i];
            waitingTimes[i] = startTime - arrivalTimes[i];
            timeInSystem[i] = endTimes[i] - arrivalTimes[i];
            queueLengths[i] = queueNo;
        }

        //Print simulation table with Queue + Idle columns
        System.out.println("\nBOOK NOOK SIMULATION TABLE (2 Counters)\n");
        System.out.printf("%-5s %-8s %-9s %-7s %-10s %-8s %-8s %-8s %-10s %-7s %-8s %-8s%n",
                "Cust", "IAT", "Arrival", "Cntr", "Service", "Start", "End", "Wait",
                "SysTime", "Queue", "C1Idle", "C2Idle");
        System.out.println("-------------------------------------------------------------------------------------------------------------");

        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            System.out.printf("%-5d %-8d %-9d %-7d %-10d %-8d %-8d %-8d %-10d %-7d %-8d %-8d%n",
                    (i + 1), interarrivalTimes[i], arrivalTimes[i], counterUsed[i],
                    serviceTimes[i], startTimes[i], endTimes[i], waitingTimes[i],
                    timeInSystem[i], queueLengths[i], counter1IdleCol[i], counter2IdleCol[i]);
        }

        //Calculate performance metrics
        double totalWait = 0, totalSys = 0, totalService = 0, totalInterarrival = 0;
        int waitedCount = 0, counter1Busy = 0, counter2Busy = 0;
        int totalC1Idle = 0, totalC2Idle = 0;

        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            totalWait += waitingTimes[i];
            totalSys += timeInSystem[i];
            totalService += serviceTimes[i];
            totalC1Idle += counter1IdleCol[i];
            totalC2Idle += counter2IdleCol[i];
            if (i > 0) totalInterarrival += interarrivalTimes[i];
            if (waitingTimes[i] > 0) waitedCount++;

            if (counterUsed[i] == 1)
                counter1Busy += serviceTimes[i];
            else
                counter2Busy += serviceTimes[i];
        }

        int totalSimTime = Math.max(counter1AvailableAt, counter2AvailableAt);
        int totalIdleTime = totalC1Idle + totalC2Idle;
        int totalBusyTime = counter1Busy + counter2Busy;

        //Compute final metrics
        double avgWait = totalWait / NUM_CUSTOMERS;
        double avgSys = totalSys / NUM_CUSTOMERS;
        double avgService = totalService / NUM_CUSTOMERS;
        double avgInterarrival = totalInterarrival / (NUM_CUSTOMERS - 1);
        double probWait = (double) waitedCount / NUM_CUSTOMERS;
        double avgWaitThoseWait = waitedCount > 0 ? totalWait / waitedCount : 0;

        double totalUtilization = (double) totalBusyTime / (2 * totalSimTime);
        double probServerIdle = (double) totalIdleTime / (2 * totalSimTime);
        double sumQueue = 0;
        for (int q : queueLengths) sumQueue += q;
        double avgQueueLength = sumQueue / NUM_CUSTOMERS;

        // Step 9: Print final performance metrics
        System.out.println("\nPERFORMANCE METRICS (FINAL 11 REQUIRED)");
        System.out.println("------------------------------------------------------");
        System.out.printf("1.  Average time in queue: %.2f%n", avgWait);
        System.out.printf("2.  Average time in system: %.2f%n", avgSys);
        System.out.printf("3.  Average queue length: %.2f%n", avgQueueLength);
        System.out.printf("4.  Server utilization: %.2f%%%n", totalUtilization * 100);
        System.out.printf("5.  Average waiting time: %.2f%n", avgWait);
        System.out.printf("6.  Probability of waiting: %.2f%n", probWait);
        System.out.printf("7.  Probability of the server being idle: %.2f%n", probServerIdle);
        System.out.printf("8.  Average service time: %.2f%n", avgService);
        System.out.printf("9.  Average time between arrivals: %.2f%n", avgInterarrival);
        System.out.printf("10. Average waiting time (for those who wait): %.2f%n", avgWaitThoseWait);
        System.out.printf("11. Average time in the system per customer: %.2f%n", avgSys);
        System.out.println("------------------------------------------------------");
        System.out.printf("Total Counter1 Idle: %d mins | Counter2 Idle: %d mins | Total Idle: %d mins%n",
                totalC1Idle, totalC2Idle, totalIdleTime);
        System.out.printf("Simulation Duration: %d mins | Total Busy: %d mins%n",
                totalSimTime, totalBusyTime);
    }


}
